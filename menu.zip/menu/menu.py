from modules.menu import mostrar_menu

if __name__ == "__main__":
    mostrar_menu()
